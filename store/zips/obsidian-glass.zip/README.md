# Obsidian Glass 1.0.0

A frosted-glass player for Mochy Music. Needs Android 13+ for the shaders (older phones fall back to Mochy's ambient background). Needs a Mochy build that has the `queue` button action and the previous/next cover images (the update that added the queue list block and volume bar).

## What it looks like

- **Disc**: frosted glass disc around a smaller round artwork, with a clear gap between them. The glass is see-through: the previous and next covers are seen softened through it (a blurred copy of each cover is drawn inside the disc), and crisp outside it. The outer ring is dial ticks with a light travelling round them while the music plays. **The ring is decoration only**: it does not show or set the song's position.
- **Previous and next covers**: the previous song's artwork peeks out from behind the disc on the left and the next song's on the right, as round covers half hidden behind the glass. Tap one to go to that song. They slide out when a song starts, and they are not drawn when there is no previous or next song (first song, last song, queue of one). Portrait only.
- **Top light**: two colours from the artwork drift across the top of the screen in opposite directions, pass through each other (where they cross they mix into a third, brighter colour) and swap sides. It only moves while the music plays. It shows on every base, **including the Blurred Artwork ones** (drawn over the blurred artwork at 78 % strength so the artwork still shows through).
- **Seek bar**: Mochy's own progress bar, in plain view (thick bar, elapsed time on the left, total on the right). What you see is what takes your finger: tap to jump, drag to scrub. Red or the artwork's own colour (Settings > Seek Bar Colour). The same bar in every mode: disc, blend and landscape.
- **Control pill**: the same frosted glass as the disc. Heart (like), lyrics, **queue**, customise, menu. The like has a pop and a ring burst.
- **Shadow**: the glass disc and the pill have a soft drop shadow. On a light base it fades out smoothly all round (it used to be cut off in a hard line under the disc, because the box holding the disc clipped it; the box now leaves 24 dp of room on every side).
- **Spacing**: no lyrics in portrait any more. The seek bar and the buttons sit up under the artwork, with an even gap between artwork, seek bar and buttons, and a larger one above the pill. The lyrics button in the pill and the "Synced Lyrics" menu entry still open Mochy's lyrics.
- **Format badge**: outlined codec pill with a light sweep, quality pill next to it.

## Settings

| Setting | Options |
|---|---|
| Background Base Color | Obsidian Black, Midnight Indigo, Deep Plum, Crimson Red, Ocean Blue, Emerald Green, Hot Pink, Soft Pearl (Light), **Blurred Artwork (Sharper / Soft / Dreamy)** |
| Text & Controls Color | White / Black (use Black on Soft Pearl) |
| Glass Style | Clear Frost / Black Frost (disc and pill) |
| Blend Artwork | the artwork becomes a full-width square that melts into the light and the base colour |
| Seek Bar Colour | Red (the concept) / Artwork Colour |
| Spinning Artwork, Format Badge | on / off |

## Seeking

- The seek bar is Mochy's own progress block, nothing hidden, nothing on top of it. A tap anywhere on the bar jumps there; a drag moves the played part with your finger and seeks when you let go.
- **The Orbit Seeker (red star, trail, orbits) is gone.** A shader can't take touches, so the only way to have it was a transparent real bar lying over it, and that is what you asked to remove. If you ever want the star back as pure decoration riding on the real bar, it is possible, but it would not follow your finger during a drag.
- **A draggable circle is not possible**: Mochy has no block that reads a finger on a circle, and the ring is decoration only.

## Blurred Artwork

Mochy's own "blurred cover" background is only a few soft colour blobs, and a module can't get the artwork itself into a background layer. So this option draws the real artwork as a block behind everything: a small cover block, scaled 17.5 times, blurred and darkened by about a third, and moved down so it fills a tall phone. It fades in when the player opens.

- Three strengths, because I could not test the blur's real size on a phone: **Sharper**, **Soft**, **Dreamy**. If all three look too sharp or too blocky, or too blurred, tell me and I'll tune the numbers.
- The top light is drawn over it by a second shader inside the same scaled block. A shader draws in the block's own coordinates, so the shader turns them back into screen positions using the block's scale (12.5) and where its middle lands (215 dp down). **That maths is checked in my preview only, not on a phone**: if the light looks misplaced, too small or missing on Blurred Artwork, send me a screenshot. Portrait only: landscape has no room in the nesting limit, so landscape shows Mochy's colour blobs under a light veil.
- With Blend Artwork on, the blend can't read this blur, so it melts into half of the artwork's main colour; expect a faint edge at the top and bottom of the blended artwork.

## Blend: what is exact and what is approximate

Each base colour has its own blend. The blend layer paints what the background looks like at that spot (same base colour, same light, same formula and same dp coordinates the background uses), and fades the artwork in and out of it, so nothing is laid over anything twice. It now fades in softly over its first 14 dp and the artwork starts below that, and the format badge keeps its space when it is off, so the blend's position no longer depends on that setting. Measured on the previews with the layer moved 25 dp either way: no step larger than one grey level between rows. The blend assumes the page starts 88 dp below the top of the screen (that is what a normal status bar gives); another status bar height only shifts the light inside the blend by a few dp, which the soft top edge hides.

## Landscape

Close arrow top left (the host draws only the drag handle there), disc on the left; song, seek bar, controls and the glass pill on the right. No format badge in landscape.

## Other limits

- Black Frost and Clear Frost only blur the background layers (a module can't make glass blur other blocks). So where the previous and next covers pass behind the glass disc the real glass can't blur them. So a second, blurred copy of each cover is drawn on top of the glass, clipped to the disc's circle: it is a look-alike frost (7 dp blur), not real glass, and it was only checked on the preview renderer, not on a phone. If the frost looks wrong on your phone (offset or too strong), tell me where it sits and I'll move or tone it.
- The top light stops where it is when you pause (no snap, no dim). A module's `playing` value is on/off, so it can't ease.
- A swipeable panel under the disc isn't possible: there's no pager or swipe block in the module format.
- **Scattered lyrics are not built** (cancelled at your request).
- The top-right heart and menu are gone, and so is the close arrow in portrait: close by dragging the player down.

## Files

`manifest.json`, `shaders/` (`top_light`, `light_fg`, `haze`, `disc`, `dock`, `badge`), `icon.png`, `banner.png`.
