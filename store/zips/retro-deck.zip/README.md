# RETRO CASSETTE DECK 1.0.3

Repositioned and resized the overlaid track title and artist so both fit within the cassette paper label instead of crossing the reel window.
