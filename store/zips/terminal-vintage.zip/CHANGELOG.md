# CHANGELOG

## 1.0.0 — Stable
- Added nine selectable theme presets with real Mochy look values.
- Added compact mode.
- Added live PLAYING / PAUSED state labels.
- Added elapsed and remaining/total duration display modes.
- Retained Geist Mono Nerd Font, synced lyrics, codec badge, native visualizer,
  playback controls, volume and output-device information.
- Enabled player scrolling for smaller displays and long lyrics.

## 1.0.1 — Alignment refinement
- Left-aligned the song title in both standard and compact layouts.
- No other player layout or functionality changed.

## 1.0.2 — Player alignment fix
- Changed player-level alignment from `center` to `start`.
- Kept both standard and compact title blocks explicitly left-aligned.
- Rows with growing spacers retain centered controls and right-aligned output details.

## 1.0.3 — Simplified time display
- Removed the Show remaining time setting.
- Kept elapsed time on the left and total track duration on the right.
- Based on the stable 1.0.2 release; no experimental artwork or mascot changes.

## 1.1.0-alpha.3
- Reworked visualizer selection to use the documented single-setting `when` equality condition on each native visualizer block, inside a `column` gated by `showVisualizer`.
- Reworked album-art colours as an option in the existing Colour theme selector. This avoids conflicts between fixed `accentColor` presets and `dynamicTheme`.
- Removed the separate album-art toggle introduced in earlier alphas; choose **Album Art** in Colour theme instead.

## 1.1.0-alpha.4
- Updated player colour fields to use Mochy's documented album-art tokens: `played` for progress and active lyrics, `cover` for the visualizer, and `accent` for the codec badge.
- Kept Alpha 3's selectable visualizer structure and Album Art theme option.

## 1.1.0-alpha.8
- Restored both embedded Geist Mono Nerd Font assets; Alpha 7 accidentally omitted the `fonts/` directory.
- Retained optional extended audio metadata, selectable visualizers and the original nine fixed theme presets.
- Album-art colour mode remains removed.

## 1.1.0 — Stable release
- Finalised the Alpha 8 feature set.
- Includes embedded Geist Mono Nerd Font regular and bold.
- Retains nine fixed colour themes.
- Includes five selectable native visualizer styles.
- Includes optional extended audio metadata.
- Retains the Terminal Vintage 1.0 player layout and elapsed/total time display.
- Album-art-derived colours are not included.
- Dynamic account-name footer is not included because Mochy does not expose a documented account-name placeholder to modules.

## 1.1.1
- Added Vice City, a neon-pink theme (`#FF5CA8`).

## 1.2.0-alpha.1
- Added dynamic UP NEXT queue metadata and queue position.
- Added a toggle to show or hide the queue section.
- Artist-profile double-tap and codec-badge detail interactions remain unimplemented because the documented player API does not expose those gestures/actions.


## 1.2.0 — Stable
- Added Counter-Strike Dust II colour theme.
- Promoted the Alpha 1 queue section and customization ordering to stable.
- Kept Visualizer style immediately below Colour theme in the customization page.
- Preserved all existing features and themes.
- FLAC badge detail and artist-profile double-tap interactions remain unsupported by the documented theme API.


## 1.00
- Re-designated the complete branded package as Terminal Velocity v1.00.
- Includes catalogue icon and banner assets referenced by the manifest.
