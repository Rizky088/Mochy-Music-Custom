# TERMINAL VINTAGE 1.0.1 — STABLE RELEASE

A modern TUI-inspired player module for Mochy Music.

## RELEASE FEATURES

### Nine theme presets
1. Vintage Monochrome
2. Catppuccin Mocha
3. One Dark
4. Dracula
5. Nord
6. Tokyo Night
7. Gruvbox
8. Everforest
9. Rosé Pine

Each theme is a Mochy setting option with its own supported `look` configuration:
- `accentColor` is set to the selected theme colour.
- `dynamicTheme` is disabled so album art does not override the chosen palette.
- `pureBlack` is enabled.

### Player
- Geist Mono Nerd Font Regular and Bold, embedded and scoped to the player.
- Three-line uppercase song title, left-aligned in standard and compact modes.
- Compact mode with a smaller title and reduced vertical spacing.
- Native PLAYING / PAUSED status using `@playing` and `@paused`.
- Native seekable progress bar.
- Elapsed time plus selectable length / remaining time.
- Native shuffle, previous, play/pause, next and repeat controls.
- Synced lyrics with active-line highlighting.
- Native mirrored audio visualizer.
- Live audio codec badge.
- Live volume percentage and output-device name.
- Scroll support for smaller screens and long lyrics.

### Customisation
The player customise sheet includes:
- Colour theme
- Compact mode
- Remaining-time display
- Show lyrics
- Show codec badge
- Show visualizer
- Show volume and output device

## INSTALL / UPDATE
1. Transfer `terminal-vintage-1.0.1.mochyymodule.zip` to your Android device.
2. In Mochy, open Settings → Modules → Add a module → Add from a file.
3. Select the ZIP. It retains the existing module ID, so Mochy updates the installed module in place.
4. Confirm the update and keep Terminal Vintage enabled.

## COMPATIBILITY NOTES
- Uses documented Mochy player blocks, placeholders, conditions, settings, setting-carried looks and time fields.
- PLAYING / PAUSED labels use native `@playing` and `@paused` conditions.
- Remaining-time mode uses the native `time` block with `show: remaining`; normal mode uses `show: length`.
- Compact mode is implemented with documented `when` conditions and alternate spacing/title blocks.
- The visualizer remains Mochy's native audio-reactive visualizer. It may remain low on passthrough outputs where Mochy cannot analyse the output signal.
- Output device and volume are read from Mochy's `{device}` and `{volume}` placeholders.

## CONTENTS
- `manifest.json`
- `README.md`
- `LICENSE`
- `fonts/GeistMonoNerdFontMono-Regular.otf`
- `fonts/GeistMonoNerdFontMono-Bold.otf`

## PROJECT
Terminal Vintage — Modern TUI
Version 1.0.1
Author: Adi

Mochy module documentation:
https://realidkroo.github.io/Mochy-Music/wiki/


## 1.0.2 ALIGNMENT FIX
THE PLAYER-LEVEL ALIGNMENT IS NOW `start`, MATCHING THE TITLE BLOCK ALIGNMENT. ROWS THAT USE GROWING SPACERS KEEP THEIR CENTERED CONTROLS AND RIGHT-ALIGNED DEVICE INFORMATION.


## 1.0.3 STABLE UPDATE
Removed the remaining-time toggle. The player always shows elapsed time on the left and total track duration on the right. This release is based on Terminal Vintage 1.0.2 and does not include the later experimental album-art or mascot changes.

### Alpha 3 implementation notes
Visualizer selection uses five native visualizer blocks, each gated by one documented setting equality condition (`visualizerStyle=...`), inside a column gated by `showVisualizer`. Album-art colours are now an option in the existing Colour theme selector, using `dynamicTheme: "true"` without an explicit `accentColor`. This avoids the documented interaction where setting `accentColor` disables cover-derived colours unless `dynamicTheme` is explicitly enabled.

### Alpha 4 colour correction
The player uses Mochy's documented dynamic colour tokens: `played` for progress and active lyrics, `cover` for the visualizer, and `accent` for the codec badge. `dynamicTheme` remains the app-wide cover-colour look setting.

### Alpha 8 font asset correction
This build includes both embedded Geist Mono Nerd Font files referenced by the manifest. Alpha 7 accidentally omitted the font assets from its ZIP archive. Extended audio metadata remains optional.

## Version 1.1.0 — Stable
Terminal Vintage 1.1.0 finalises the Alpha 8 feature set. It includes Geist Mono Nerd Font assets, nine fixed theme presets, five native visualizer styles, and an optional extended audio metadata line. Album-art-derived colours and a dynamic account-name footer are not included.

## Version 1.1.1
Adds the **Vice City** neon-pink theme. All existing features and Geist Mono Nerd Font assets are retained.


## v1.2.0-alpha.1

- Added a dynamic **UP NEXT** section using Mochy's `{next}` and `{nextArtist}` placeholders.
- Added queue position and size using `{queuePosition}` and `{queueSize}`.
- Added a `Show Up Next queue` toggle, enabled by default.
- Preserved all ten themes, including Vice City, and the embedded Geist Mono Nerd Font files.

### API limitations for this alpha

The current public player documentation does not expose a tap action for a text/artist block, a double-tap gesture for artist navigation, or a codec-details action. Those two requested interactions are therefore not simulated in this build. They remain pending native Mochy support.


## v1.2.0 — Stable

- Promoted the v1.2 Alpha 1 work to the stable 1.2.0 release.
- Added **Counter-Strike Dust II** colour theme with a sandstone/desert-amber accent (`#D6A46D`).
- Kept **Visualizer style** directly below **Colour theme** in the customization page.
- Includes the dynamic **UP NEXT** queue section, using `{next}`, `{nextArtist}`, `{queuePosition}`, and `{queueSize}`.
- Retains all previous themes, including Vice City, and both embedded Geist Mono Nerd Font files.

The FLAC badge detail action and double-tap artist-profile navigation are not included because the documented Mochy theme API does not expose those interactions.


## Mochy catalogue branding

This v1.2.0 package includes the catalogue assets using Mochy's module manifest paths:

- `images/icon.png` — Terminal Velocity module icon (512 × 512).
- `images/banner.webp` — Terminal Velocity module banner (1600 × 623).

The manifest points to both assets via its `icon` and `banner` fields.


## v1.00 — First branded release

The complete Terminal Velocity package is designated **v1.00**. This release includes the Mochy catalogue icon and banner, all eleven colour themes, the UP NEXT queue section, visualizer style selection, and embedded Geist Mono Nerd Font assets.


## Module description
A modern terminal-inspired music player look for Mochy, with a clean TUI layout, customizable themes, synced lyrics, audio visualizers and queue details.
